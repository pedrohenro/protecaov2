#!/usr/bin/env python3
"""
DIAGNÓSTICO DE PYTHON
Detecta e resolve problemas de instalação/PATH
"""

import os
import sys
import subprocess
import platform
import winreg
from pathlib import Path

class DiagnosticoPython:
    def __init__(self):
        self.sistema = platform.system()
        self.python_paths = []
        self.problemas = []
        self.solucoes = []
    
    def executar(self):
        """Executa diagnóstico completo"""
        self._limpar_tela()
        
        print("=" * 70)
        print("🔧 DIAGNÓSTICO COMPLETO DE PYTHON")
        print("=" * 70)
        
        print("\n[1/6] Verificando Python atual...")
        self._verificar_python_atual()
        
        print("\n[2/6] Procurando instalações de Python...")
        self._procurar_python()
        
        print("\n[3/6] Verificando PATH...")
        self._verificar_path()
        
        print("\n[4/6] Verificando Registry (Windows)...")
        if self.sistema == "Windows":
            self._verificar_registry()
        else:
            print("   ⏭️  Pulado (não é Windows)")
        
        print("\n[5/6] Testando pip...")
        self._testar_pip()
        
        print("\n[6/6] Gerando relatório...")
        self._gerar_relatorio()
        
        print("\n" + "=" * 70)
        print("📋 RESUMO E SOLUÇÕES")
        print("=" * 70)
        
        if self.problemas:
            print(f"\n❌ PROBLEMAS ENCONTRADOS ({len(self.problemas)}):\n")
            for i, prob in enumerate(self.problemas, 1):
                print(f"  {i}. {prob}")
        else:
            print("\n✅ Python está funcionando corretamente!")
        
        if self.solucoes:
            print(f"\n✅ SOLUÇÕES SUGERIDAS ({len(self.solucoes)}):\n")
            for i, sol in enumerate(self.solucoes, 1):
                print(f"  {i}. {sol}")
        
        print("\n" + "=" * 70)
    
    def _limpar_tela(self):
        if self.sistema == "Windows":
            os.system("cls")
        else:
            os.system("clear")
    
    def _verificar_python_atual(self):
        """Verifica Python que está rodando agora"""
        print(f"   Python: {sys.executable}")
        print(f"   Versão: {sys.version}")
        
        try:
            resultado = subprocess.run(
                [sys.executable, "--version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            print(f"   ✅ Python respondendo: {resultado.stdout.strip()}")
        except Exception as e:
            print(f"   ❌ Erro ao testar: {e}")
            self.problemas.append("Python não responde a comando --version")
    
    def _procurar_python(self):
        """Procura instalações de Python em locais comuns"""
        if self.sistema == "Windows":
            locais = [
                "C:\\Python311",
                "C:\\Python310",
                "C:\\Python39",
                "C:\\Python38",
                "C:\\Program Files\\Python311",
                "C:\\Program Files\\Python310",
                "C:\\Program Files\\Python39",
                "C:\\Program Files\\Python38",
                "C:\\Users\\*\\AppData\\Local\\Programs\\Python\\Python311",
            ]
            
            for local in locais:
                if "*" in local:
                    continue
                python_exe = Path(local) / "python.exe"
                if python_exe.exists():
                    print(f"   ✅ Encontrado: {python_exe}")
                    self.python_paths.append(str(python_exe))
            
            if not self.python_paths:
                print("   ❌ Nenhuma instalação encontrada")
                self.problemas.append("Nenhuma instalação de Python encontrada em locais padrão")
                self.solucoes.append("Instale Python em https://www.python.org/downloads/")
        else:
            resultado = subprocess.run(
                ["which", "python3"],
                capture_output=True,
                text=True
            )
            if resultado.returncode == 0:
                print(f"   ✅ Encontrado: {resultado.stdout.strip()}")
                self.python_paths.append(resultado.stdout.strip())
            else:
                print("   ❌ python3 não encontrado")
                self.problemas.append("python3 não está no PATH")
    
    def _verificar_path(self):
        """Verifica se Python está no PATH"""
        path = os.environ.get("PATH", "").split(os.pathsep)
        
        python_no_path = False
        for p in path:
            if "python" in p.lower():
                print(f"   ✅ PATH contém: {p}")
                python_no_path = True
        
        if not python_no_path:
            print("   ❌ PATH não contém nenhum diretório Python")
            self.problemas.append("Python não está configurado no PATH")
            if self.python_paths:
                self.solucoes.append(
                    f"Adicione ao PATH: {Path(self.python_paths[0]).parent}"
                )
    
    def _verificar_registry(self):
        """Verifica registry do Windows"""
        try:
            with winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                "SOFTWARE\\Python\\PythonCore"
            ) as key:
                subkeys = []
                for i in range(winreg.QueryInfoKey(key)[0]):
                    subkey_name = winreg.EnumKeyEx(key, i)[0]
                    subkeys.append(subkey_name)
                
                if subkeys:
                    print(f"   ✅ Python no Registry: {', '.join(subkeys)}")
                else:
                    print("   ❌ Nenhuma entrada Python no Registry")
        except Exception as e:
            print(f"   ⚠️  Erro ao acessar Registry: {e}")
    
    def _testar_pip(self):
        """Testa se pip funciona"""
        try:
            resultado = subprocess.run(
                [sys.executable, "-m", "pip", "--version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            if resultado.returncode == 0:
                print(f"   ✅ pip funcionando: {resultado.stdout.strip()}")
            else:
                print(f"   ⚠️  pip com problema: {resultado.stderr[:50]}")
                self.problemas.append("pip não está funcionando corretamente")
        except Exception as e:
            print(f"   ❌ Erro ao testar pip: {e}")
            self.problemas.append("pip não respondeu")
    
    def _gerar_relatorio(self):
        """Gera relatório detalhado"""
        print("\n📝 RELATÓRIO DETALHADO:")
        print(f"   Sistema Operacional: {platform.platform()}")
        print(f"   Python Executável: {sys.executable}")
        print(f"   Versão Python: {sys.version.split()[0]}")
        print(f"   Caminho do Site-Packages: {sys.base_prefix}")
        print(f"   Instalações Encontradas: {len(self.python_paths)}")
        
        if self.python_paths:
            print(f"\n   Caminhos de Python:")
            for path in self.python_paths:
                print(f"     - {path}")


class ResolvedorAutomatico:
    """Tenta resolver problemas automaticamente"""
    
    @staticmethod
    def executar_com_python_completo():
        """Executa script com caminho completo de Python"""
        print("\n🚀 Tentando executar com caminho completo...\n")
        
        try:
            # Tenta encontrar Python
            python_exe = None
            
            locais = [
                "C:\\Python311\\python.exe",
                "C:\\Python310\\python.exe",
                "C:\\Python39\\python.exe",
                "C:\\Program Files\\Python311\\python.exe",
                "C:\\Program Files\\Python310\\python.exe",
            ]
            
            for local in locais:
                if Path(local).exists():
                    python_exe = local
                    break
            
            if not python_exe:
                print("❌ Nenhuma instalação de Python encontrada")
                return False
            
            print(f"✅ Python encontrado: {python_exe}\n")
            
            # Tenta executar o script
            if Path("protecao_maquina.py").exists():
                print("Executando protecao_maquina.py...\n")
                subprocess.run([python_exe, "protecao_maquina.py"])
                return True
            else:
                print("❌ Arquivo protecao_maquina.py não encontrado")
                return False
        
        except Exception as e:
            print(f"❌ Erro: {e}")
            return False
    
    @staticmethod
    def criar_script_wrapper():
        """Cria script wrapper para executar Python corretamente"""
        script = """@echo off
REM Script wrapper para executar Python corretamente

setlocal enabledelayedexpansion

set "python_paths=C:\\Python311\\python.exe C:\\Python310\\python.exe C:\\Python39\\python.exe C:\\Program Files\\Python311\\python.exe C:\\Program Files\\Python310\\python.exe"

for %%P in (!python_paths!) do (
    if exist "%%P" (
        echo ✅ Usando Python: %%P
        "%%P" protecao_maquina.py
        goto :fim
    )
)

echo ❌ Python não encontrado!
pause
exit /b 1

:fim
pause
"""
        
        with open("EXECUTAR_COM_PYTHON.bat", "w") as f:
            f.write(script)
        
        print("✅ Script wrapper criado: EXECUTAR_COM_PYTHON.bat")


def main():
    """Função principal"""
    try:
        diagnostico = DiagnosticoPython()
        diagnostico.executar()
        
        input("\n\nPressione ENTER para continuar...")
        
        print("\n" + "=" * 70)
        print("🔄 PRÓXIMAS ETAPAS")
        print("=" * 70)
        
        opcoes = [
            "Executar com Python Completo",
            "Criar Script Wrapper",
            "Sair"
        ]
        
        for i, opcao in enumerate(opcoes, 1):
            print(f"[{i}] {opcao}")
        
        escolha = input("\nEscolha (1-3): ").strip()
        
        if escolha == "1":
            ResolvedorAutomatico.executar_com_python_completo()
        elif escolha == "2":
            ResolvedorAutomatico.criar_script_wrapper()
            print("✅ Tente executar: EXECUTAR_COM_PYTHON.bat")
        else:
            print("Saindo...")
    
    except KeyboardInterrupt:
        print("\n\nInterrompido pelo usuário")
    except Exception as e:
        print(f"\n❌ Erro: {e}")


if __name__ == "__main__":
    main()
