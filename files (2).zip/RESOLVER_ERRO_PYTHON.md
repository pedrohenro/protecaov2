# 🔧 RESOLVENDO ERRO: "Python não está instalado"

Você tem Python instalado mas o CMD não reconhece? Este guia resolve!

---

## ⚡ Solução Rápida (30 segundos)

### 1️⃣ Baixe o arquivo de diagnóstico
```
DIAGNOSTICO_PYTHON.bat
```

### 2️⃣ Clique duplo para executar
- Ele encontrará seu Python
- Oferecerá opções de correção automática

### 3️⃣ Siga as instruções na tela

**Pronto! Problema resolvido.**

---

## 🔍 Por Que Acontece?

O Python está instalado no computador, mas Windows não encontra porque:

❌ **Python não está no PATH**
- PATH é a lista de pastas onde Windows procura programas
- Python instalado mas não adicionado ao PATH = invisível para CMD

❌ **Instalou mas não marcou "Add Python to PATH"**
- Erro durante instalação
- Opção não selecionada

❌ **Instalação corrompida**
- Arquivo corrompido durante download
- Instalação incompleta

---

## 📋 SOLUÇÃO MANUAL (Se o diagnóstico não funcionar)

### **OPÇÃO A: Reinstalar Python (Melhor)**

#### Passo 1: Desinstale Python Atual
1. Abra: `Painel de Controle` → `Programas` → `Programas e Recursos`
2. Procure por `Python`
3. Clique em `Python X.X` → `Desinstalar`
4. Clique `Yes` para remover tudo

#### Passo 2: Baixe Python Novamente
1. Acesse: https://www.python.org/downloads/
2. Clique em **"Download Python 3.11"** (ou versão mais recente)

#### Passo 3: Instale Corretamente
1. Execute o instalador
2. **IMPORTANTE**: Marque ☑️ **"Add Python to PATH"**
3. Clique em `Install Now`
4. Aguarde instalação completar
5. Clique `Close`

#### Passo 4: Reinicie Computador
1. Pressione `WIN + X`
2. Escolha `Desligar`
3. Reinicie o PC

#### Passo 5: Teste
1. Abra CMD
2. Digite: `python --version`
3. Se aparecer versão → **Funcionou!**

---

### **OPÇÃO B: Adicionar ao PATH Manualmente**

Se reinstalar não funcionar:

#### Windows 10/11:

**Passo 1: Encontre aonde Python está instalado**
1. Abra `Explorador de Arquivos`
2. Digite na barra de endereço:
   ```
   C:\Users\%username%\AppData\Local\Programs\Python
   ```
3. Procure por pasta como `Python311`, `Python310`, etc.
4. Copie o caminho completo da pasta

**Passo 2: Adicione ao PATH**
1. Pressione `WIN + X`
2. Procure e abra `Variáveis de Ambiente`
3. Clique em `Variáveis de Ambiente` (botão na parte inferior)
4. Em "Variáveis do usuário", clique em `Path`
5. Clique em `Editar`
6. Clique em `Novo`
7. Cole o caminho que copiou (ex: `C:\Python311`)
8. Clique `OK` em todas as janelas
9. **Reinicie o computador**

#### Windows 7/8:

1. Clique direito em `Meu Computador` → `Propriedades`
2. Clique em `Variáveis de Ambiente`
3. Em "Variáveis do sistema", procure por `Path`
4. Clique em `Editar`
5. No final, adicione:
   ```
   ;C:\Python311
   ```
   (Ajuste o número da versão conforme necessário)
6. Clique `OK` → `OK` → `OK`
7. Reinicie o computador

---

### **OPÇÃO C: Use Caminho Completo**

Se não quiser adicionar ao PATH, pode usar o caminho completo:

#### Encontre o caminho:
1. Abra `Explorador de Arquivos`
2. Navegue para: `C:\Users\SeuUsuario\AppData\Local\Programs\Python\Python311`
3. Copie o endereço completo

#### Use na linha de comando:
```cmd
C:\Users\SeuUsuario\AppData\Local\Programs\Python\Python311\python.exe protecao_maquina.py
```

---

## 🆘 Ainda Não Funciona?

### Teste 1: Procure Python em outro lugar
```cmd
where python
where python3
python -c "import sys; print(sys.executable)"
```

### Teste 2: Use Python3 em vez de Python
```cmd
python3 --version
python3 protecao_maquina.py
```

### Teste 3: Procure manualmente
Navegue até:
- `C:\Program Files\Python311`
- `C:\Program Files (x86)\Python311`
- `C:\Python311`
- `C:\Users\[SeuNome]\AppData\Local\Programs\Python\Python311`

### Teste 4: Verifique permissões
1. Clique direito em `python.exe`
2. `Propriedades` → `Geral`
3. Verifique se há aviso de "Este arquivo veio de outro computador"
4. Se houver, marque `Desbloquear` e clique `Aplicar`

---

## ✅ VERIFICAR SE FUNCIONOU

Abra um **NOVO CMD** e teste:

```cmd
python --version
```

Se aparecer algo como:
```
Python 3.11.0
```

**✅ FUNCIONOU!**

Agora pode executar:
```cmd
python protecao_maquina.py
```

---

## 🎯 Resumo Rápido

| Problema | Solução |
|----------|---------|
| "Python não é reconhecido" | Reinstale com "Add to PATH" |
| "Instalei mas ainda não funciona" | Reinicie o computador |
| "Continua não funcionando" | Execute com caminho completo |
| "Preciso de ajuda" | Use DIAGNOSTICO_PYTHON.bat |

---

## 🤖 Solução Automática

Se está difícil, use o script de diagnóstico:

```bash
DIAGNOSTICO_PYTHON.bat
```

Ele:
1. ✅ Localiza Python automaticamente
2. ✅ Diagnostica o problema
3. ✅ Oferece soluções automáticas
4. ✅ Executa o programa se possível

---

## 📞 Checklist Final

- ✅ Desinstalei Python antigas
- ✅ Baixei Python novo de python.org
- ✅ Executei instalador
- ✅ Marquei "Add Python to PATH"
- ✅ Reiniciei computador
- ✅ Testei `python --version` em NOVO CMD
- ✅ Vejo a versão do Python
- ✅ Pronto para rodar `protecao_maquina.py`

---

## 💡 Dica Pro

Se está com pressa:

1. Abra o `DIAGNOSTICO_PYTHON.bat`
2. Aperte opção `[1]` Executar com Python Completo
3. Pronto! Ele achará e executará automaticamente

---

**🛡️ Resolvido! Agora sua proteção funciona!**
