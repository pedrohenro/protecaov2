@echo off
REM ============================================================
REM DIAGNÓSTICO E CORREÇÃO DE PYTHON
REM ============================================================
REM Este script detecta e resolve problemas com Python

setlocal enabledelayedexpansion

cls
echo.
echo ============================================================
echo        🔧 DIAGNÓSTICO DE PYTHON
echo ============================================================
echo.

REM Teste 1: Procura python no PATH
echo [1/5] Procurando python no PATH...
python --version >nul 2>&1
if %errorlevel% equ 0 (
    echo ✅ Python encontrado no PATH
    python --version
) else (
    echo ❌ Python NÃO encontrado com comando 'python'
)

echo.

REM Teste 2: Procura python3 no PATH
echo [2/5] Procurando python3 no PATH...
python3 --version >nul 2>&1
if %errorlevel% equ 0 (
    echo ✅ Python3 encontrado no PATH
    python3 --version
) else (
    echo ❌ Python3 NÃO encontrado com comando 'python3'
)

echo.

REM Teste 3: Procura Python no Program Files
echo [3/5] Procurando Python nos Program Files...
set "python_path="

if exist "C:\Python311\python.exe" (
    set "python_path=C:\Python311\python.exe"
    echo ✅ Python 3.11 encontrado em C:\Python311\
) else if exist "C:\Python310\python.exe" (
    set "python_path=C:\Python310\python.exe"
    echo ✅ Python 3.10 encontrado em C:\Python310\
) else if exist "C:\Python39\python.exe" (
    set "python_path=C:\Python39\python.exe"
    echo ✅ Python 3.9 encontrado em C:\Python39\
) else if exist "C:\Program Files\Python311\python.exe" (
    set "python_path=C:\Program Files\Python311\python.exe"
    echo ✅ Python 3.11 encontrado em Program Files
) else if exist "C:\Program Files\Python310\python.exe" (
    set "python_path=C:\Program Files\Python310\python.exe"
    echo ✅ Python 3.10 encontrado em Program Files
) else if exist "C:\Program Files\Python39\python.exe" (
    set "python_path=C:\Program Files\Python39\python.exe"
    echo ✅ Python 3.9 encontrado em Program Files
) else (
    echo ❌ Python NÃO encontrado em Program Files
)

echo.

REM Teste 4: Procura no registry
echo [4/5] Procurando Python no registro do Windows...
for /f "tokens=2*" %%A in ('reg query "HKEY_LOCAL_MACHINE\SOFTWARE\Python\PythonCore" 2^>nul ^| findstr InstallPath') do (
    set "python_path=%%B"
)

if not "!python_path!"=="" (
    echo ✅ Python encontrado no Registry: !python_path!
) else (
    echo ❌ Python NÃO encontrado no Registry
)

echo.

REM Teste 5: Verificar PATH
echo [5/5] Conteúdo da variável PATH:
echo -------
set PATH
echo -------

echo.
echo ============================================================
echo        📋 SOLUÇÕES
echo ============================================================
echo.

REM Se encontrou Python, oferece opção de adicionar ao PATH
if not "!python_path!"=="" (
    echo ✅ Python foi encontrado em: !python_path!
    echo.
    echo Opções:
    echo [1] Executar script com caminho completo de Python
    echo [2] Adicionar Python ao PATH (permanente)
    echo [3] Sair
    echo.
    set /p opcao="Escolha uma opção (1-3): "
    
    if "!opcao!"=="1" (
        call :executar_com_caminho "!python_path!"
    ) else if "!opcao!"=="2" (
        call :adicionar_path "!python_path!"
    ) else (
        goto :fim
    )
) else (
    echo ❌ Python NÃO foi encontrado no computador!
    echo.
    echo 📥 SOLUÇÃO: Instale Python
    echo.
    echo 1. Visite: https://www.python.org/downloads/
    echo 2. Clique em "Download Python 3.11" (ou versão mais recente)
    echo 3. Execute o instalador
    echo 4. ⚠️  IMPORTANTE: Marque a opção:
    echo    ☑️  "Add Python to PATH"
    echo 5. Clique em "Install Now"
    echo 6. Reinicie o computador
    echo 7. Execute este script novamente
    echo.
)

goto :fim

:executar_com_caminho
setlocal enabledelayedexpansion
set "python_exe=%~1"

echo.
echo 🚀 Executando proteção_maquina.py com Python completo...
echo Comando: "!python_exe!" protecao_maquina.py
echo.

REM Verifica se arquivo existe
if exist "protecao_maquina.py" (
    "!python_exe!" protecao_maquina.py
) else (
    echo ❌ ERRO: Arquivo 'protecao_maquina.py' não encontrado!
    echo.
    echo Certifique-se de que protecao_maquina.py está na mesma pasta
    echo.
)

endlocal
goto :fim

:adicionar_path
setlocal enabledelayedexpansion
set "python_exe=%~1"
set "python_dir=!python_exe:\python.exe=!"

echo.
echo 🔧 Adicionando Python ao PATH permanentemente...
echo.

REM Adiciona ao PATH do usuário
setx PATH "!python_dir!;%PATH%"

if %errorlevel% equ 0 (
    echo ✅ Python adicionado ao PATH com sucesso!
    echo.
    echo 📝 Próximos passos:
    echo 1. Feche todas as janelas de CMD
    echo 2. Abra uma NOVA janela de CMD
    echo 3. Digite: python --version
    echo 4. Se aparecer versão, funcionou!
    echo 5. Execute: python protecao_maquina.py
    echo.
) else (
    echo ❌ Erro ao adicionar ao PATH
    echo Você pode estar sem permissões de administrador
    echo.
    echo Tente:
    echo 1. Clique direito em CMD
    echo 2. "Executar como administrador"
    echo 3. Execute este script novamente
    echo.
)

endlocal
goto :fim

:fim
echo.
echo Pressione ENTER para sair...
pause >nul
exit /b 0
