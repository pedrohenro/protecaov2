#!/usr/bin/env python3
"""
Script de Testes e Demonstração
Teste todos os componentes do sistema de proteção
"""

import os
import sys
import json
import tempfile
from pathlib import Path
from vm_protection_system import VMProtectionSystem
from exemplo_integracao import ProtectedApplication, LicenseGenerator


class TestSuite:
    def __init__(self):
        self.passed = 0
        self.failed = 0
        self.protection = VMProtectionSystem()
    
    def run_all(self):
        """Executa todos os testes"""
        print("="*70)
        print("SUITE DE TESTES - Sistema de Proteção contra Pirataria")
        print("="*70)
        
        self.test_machine_id()
        self.test_vm_detection()
        self.test_license_generation()
        self.test_license_validation()
        self.test_license_tampering()
        self.test_license_expiration()
        self.test_machine_binding()
        self.test_integrity_check()
        self.test_debugger_detection()
        
        self.print_summary()
    
    def test_machine_id(self):
        """Teste 1: Geração de Machine ID"""
        print("\n[Teste 1] Geração de Machine ID")
        print("-" * 70)
        
        try:
            machine_id = self.protection.machine_id
            assert len(machine_id) == 16, "Machine ID deve ter 16 caracteres"
            assert all(c in '0123456789abcdef' for c in machine_id), "Machine ID deve ser hexadecimal"
            
            print(f"✅ Machine ID gerado: {machine_id}")
            print(f"✅ Formato válido (hex, 16 chars)")
            self.passed += 1
        except Exception as e:
            print(f"❌ Erro: {e}")
            self.failed += 1
    
    def test_vm_detection(self):
        """Teste 2: Detecção de VM"""
        print("\n[Teste 2] Detecção de Máquina Virtual")
        print("-" * 70)
        
        try:
            vm_check = self.protection.detect_virtual_machine()
            
            assert "is_vm" in vm_check, "Resultado deve conter 'is_vm'"
            assert "vm_type" in vm_check, "Resultado deve conter 'vm_type'"
            assert "detection_methods" in vm_check, "Resultado deve conter 'detection_methods'"
            
            status = "VM DETECTADA" if vm_check["is_vm"] else "Sistema Nativo"
            print(f"✅ Status: {status}")
            
            if vm_check["is_vm"]:
                print(f"   Métodos de detecção:")
                for method in vm_check["detection_methods"]:
                    print(f"     - {method}")
            
            self.passed += 1
        except Exception as e:
            print(f"❌ Erro: {e}")
            self.failed += 1
    
    def test_license_generation(self):
        """Teste 3: Geração de Licença"""
        print("\n[Teste 3] Geração de Licença")
        print("-" * 70)
        
        try:
            license = self.protection.generate_license("Teste Cliente", days_valid=30)
            
            assert isinstance(license, str), "Licença deve ser string"
            assert len(license) > 100, "Licença deve ser suficientemente longa"
            
            # Valida JSON
            license_data = json.loads(license)
            assert "data" in license_data, "Licença deve conter 'data'"
            assert "signature" in license_data, "Licença deve conter 'signature'"
            
            print(f"✅ Licença gerada com sucesso")
            print(f"✅ Tamanho: {len(license)} caracteres")
            print(f"✅ Formato JSON válido")
            print(f"✅ Cliente: {license_data['data']['customer']}")
            
            self.passed += 1
        except Exception as e:
            print(f"❌ Erro: {e}")
            self.failed += 1
    
    def test_license_validation(self):
        """Teste 4: Validação de Licença"""
        print("\n[Teste 4] Validação de Licença")
        print("-" * 70)
        
        try:
            # Gera licença
            license = self.protection.generate_license("Teste Válido", days_valid=365)
            
            # Valida
            valid, message = self.protection.validate_license(license)
            
            assert valid is True, "Licença válida deve retornar True"
            assert "válida" in message.lower(), "Mensagem deve indicar sucesso"
            
            print(f"✅ Licença válida: {message}")
            self.passed += 1
        except Exception as e:
            print(f"❌ Erro: {e}")
            self.failed += 1
    
    def test_license_tampering(self):
        """Teste 5: Detecção de Tampering"""
        print("\n[Teste 5] Detecção de Modificação de Licença")
        print("-" * 70)
        
        try:
            # Gera licença válida
            license = self.protection.generate_license("Teste Tampering", days_valid=365)
            
            # Tenta modificar
            license_data = json.loads(license)
            license_data["data"]["customer"] = "Cliente Modificado"
            modified_license = json.dumps(license_data)
            
            # Valida modificada
            valid, message = self.protection.validate_license(modified_license)
            
            assert valid is False, "Licença modificada deve ser inválida"
            assert "assinatura" in message.lower() or "modificada" in message.lower(), "Mensagem deve indicar tampering"
            
            print(f"✅ Modificação detectada: {message}")
            self.passed += 1
        except Exception as e:
            print(f"❌ Erro: {e}")
            self.failed += 1
    
    def test_license_expiration(self):
        """Teste 6: Validação de Expiração"""
        print("\n[Teste 6] Validação de Expiração de Licença")
        print("-" * 70)
        
        try:
            # Gera licença com 1 segundo de duração
            from datetime import datetime, timedelta
            
            license = self.protection.generate_license("Teste Expiração", days_valid=0)
            
            # Modifica data de expiração para passado
            license_data = json.loads(license)
            license_data["data"]["expires"] = (datetime.now() - timedelta(days=1)).isoformat()
            license_json = json.dumps(license_data, sort_keys=True)
            license_data["signature"] = self.protection._sign_license(license_json)
            expired_license = json.dumps(license_data)
            
            # Valida
            valid, message = self.protection.validate_license(expired_license)
            
            assert valid is False, "Licença expirada deve ser inválida"
            assert "expirad" in message.lower(), "Mensagem deve indicar expiração"
            
            print(f"✅ Expiração detectada: {message}")
            self.passed += 1
        except Exception as e:
            print(f"❌ Erro: {e}")
            self.failed += 1
    
    def test_machine_binding(self):
        """Teste 7: Binding de Hardware"""
        print("\n[Teste 7] Binding de Machine ID")
        print("-" * 70)
        
        try:
            # Gera licença
            license = self.protection.generate_license("Teste Hardware", days_valid=365)
            license_data = json.loads(license)
            
            # Verifica que machine_id está na licença
            stored_machine_id = license_data["data"]["machine_id"]
            current_machine_id = self.protection.machine_id
            
            assert stored_machine_id == current_machine_id, "Machine ID deve estar na licença"
            
            # Tenta usar em machine_id diferente
            license_data["data"]["machine_id"] = "different_machine_id"
            license_json = json.dumps(license_data, sort_keys=True)
            license_data["signature"] = self.protection._sign_license(license_json)
            wrong_machine_license = json.dumps(license_data)
            
            valid, message = self.protection.validate_license(wrong_machine_license)
            
            assert valid is False, "Licença com machine_id diferente deve ser inválida"
            assert "computador" in message.lower() or "machine" in message.lower(), "Mensagem deve indicar machine_id"
            
            print(f"✅ Machine ID armazenado: {stored_machine_id[:8]}...")
            print(f"✅ Detecção de machine_id diferente: {message}")
            self.passed += 1
        except Exception as e:
            print(f"❌ Erro: {e}")
            self.failed += 1
    
    def test_integrity_check(self):
        """Teste 8: Verificação de Integridade"""
        print("\n[Teste 8] Verificação de Integridade de Arquivo")
        print("-" * 70)
        
        try:
            # Cria arquivo temporário
            with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.txt') as f:
                f.write("Conteúdo original do arquivo")
                temp_file = f.name
            
            try:
                # Primeira verificação (registra hash)
                valid1, msg1 = self.protection.check_integrity(temp_file)
                assert "registrado" in msg1.lower() or "confirmada" in msg1.lower(), "Primeira verificação deve registrar arquivo"
                
                # Segunda verificação (sem modificação)
                valid2, msg2 = self.protection.check_integrity(temp_file)
                assert valid2 is True, "Segunda verificação deve passar"
                assert "confirmada" in msg2.lower(), "Mensagem deve indicar integridade"
                
                # Modifica arquivo
                with open(temp_file, 'w') as f:
                    f.write("Conteúdo modificado")
                
                # Terceira verificação (com modificação)
                valid3, msg3 = self.protection.check_integrity(temp_file)
                assert valid3 is False, "Arquivo modificado deve falhar"
                assert "modificado" in msg3.lower() or "alerta" in msg3.lower(), "Mensagem deve indicar modificação"
                
                print(f"✅ Arquivo registrado e monitorado")
                print(f"✅ Modificação detectada: {msg3}")
                self.passed += 1
            finally:
                os.unlink(temp_file)
        except Exception as e:
            print(f"❌ Erro: {e}")
            self.failed += 1
    
    def test_debugger_detection(self):
        """Teste 9: Detecção de Debugger"""
        print("\n[Teste 9] Detecção de Debugger")
        print("-" * 70)
        
        try:
            is_debugged, methods = self.protection.detect_debugger()
            
            assert isinstance(is_debugged, bool), "Resultado deve ser booleano"
            assert isinstance(methods, list), "Métodos deve ser lista"
            
            if is_debugged:
                print(f"⚠️  Debugger detectado:")
                for method in methods:
                    print(f"   - {method}")
            else:
                print(f"✅ Nenhum debugger detectado")
            
            self.passed += 1
        except Exception as e:
            print(f"❌ Erro: {e}")
            self.failed += 1
    
    def print_summary(self):
        """Imprime resumo dos testes"""
        total = self.passed + self.failed
        percentage = (self.passed / total * 100) if total > 0 else 0
        
        print("\n" + "="*70)
        print("RESUMO DOS TESTES")
        print("="*70)
        print(f"✅ Passou: {self.passed}")
        print(f"❌ Falhou: {self.failed}")
        print(f"📊 Total:  {total}")
        print(f"📈 Taxa:   {percentage:.1f}%")
        print("="*70)


class DemoMode:
    """Modo demonstração interativo"""
    
    def __init__(self):
        self.protection = VMProtectionSystem()
        self.generator = LicenseGenerator()
    
    def run(self):
        """Executa demonstração"""
        print("\n" + "="*70)
        print("MODO DEMONSTRAÇÃO - Sistema de Proteção")
        print("="*70)
        
        while True:
            print("\nOpções:")
            print("1. Ver Machine ID")
            print("2. Gerar Licença")
            print("3. Validar Licença")
            print("4. Simular Aplicação Protegida")
            print("5. Verificar VM")
            print("6. Verificar Debugger")
            print("0. Sair")
            
            choice = input("\nEscolha uma opção (0-6): ").strip()
            
            if choice == "1":
                self.show_machine_id()
            elif choice == "2":
                self.generate_license()
            elif choice == "3":
                self.validate_license()
            elif choice == "4":
                self.simulate_app()
            elif choice == "5":
                self.check_vm()
            elif choice == "6":
                self.check_debugger()
            elif choice == "0":
                print("\nSaindo...")
                break
            else:
                print("Opção inválida!")
    
    def show_machine_id(self):
        print(f"\nMachine ID: {self.protection.machine_id}")
        print("Este é o identificador único desta máquina")
    
    def generate_license(self):
        customer = input("\nNome do cliente: ")
        days = input("Dias válido (padrão 365): ").strip() or "365"
        
        try:
            license = self.protection.generate_license(customer, int(days))
            print(f"\n✅ Licença gerada com sucesso!")
            print(f"Primeiros 100 caracteres: {license[:100]}...")
        except ValueError:
            print("❌ Dias deve ser um número")
    
    def validate_license(self):
        license_str = input("\nCole a licença (JSON): ").strip()
        
        valid, msg = self.protection.validate_license(license_str)
        print(f"\n{msg}")
    
    def simulate_app(self):
        print("\nSimulando aplicação protegida...")
        
        # Gera licença temporária
        license = self.protection.generate_license("Demo App", days_valid=1)
        
        with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.lic') as f:
            f.write(license)
            license_file = f.name
        
        try:
            app = ProtectedApplication("Demo App", license_file)
            if app.verify_and_start():
                app.run()
        finally:
            os.unlink(license_file)
    
    def check_vm(self):
        vm_check = self.protection.detect_virtual_machine()
        
        print(f"\n{'VM Detectada' if vm_check['is_vm'] else 'Sistema Nativo'}")
        if vm_check['is_vm']:
            print("Métodos de detecção:")
            for method in vm_check['detection_methods']:
                print(f"  - {method}")
    
    def check_debugger(self):
        is_debugged, methods = self.protection.detect_debugger()
        
        print(f"\n{'Debugger Detectado' if is_debugged else 'Nenhum Debugger'}")
        if is_debugged:
            for method in methods:
                print(f"  - {method}")


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Sistema de Proteção contra Pirataria")
    parser.add_argument("--test", action="store_true", help="Executar testes")
    parser.add_argument("--demo", action="store_true", help="Modo demonstração")
    parser.add_argument("--quick", action="store_true", help="Teste rápido")
    
    args = parser.parse_args()
    
    if args.test or args.quick:
        suite = TestSuite()
        suite.run_all()
    elif args.demo:
        demo = DemoMode()
        demo.run()
    else:
        # Padrão: teste rápido
        print("Uso: python testes.py [--test|--demo|--quick]")
        print("\nExecutando teste rápido...\n")
        
        suite = TestSuite()
        suite.test_machine_id()
        suite.test_vm_detection()
        suite.test_license_generation()
        suite.test_license_validation()
        suite.print_summary()


if __name__ == "__main__":
    main()
