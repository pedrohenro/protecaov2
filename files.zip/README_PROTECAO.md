# Sistema de Proteção contra Pirataria para VMs

## 📋 Visão Geral

Um sistema robusto de proteção de software contra pirataria que inclui:

- ✅ **Detecção de Máquina Virtual** - Identifica se está rodando em VM (VMware, VirtualBox, Hyper-V, KVM)
- ✅ **Validação de Licença** - Sistema de assinatura criptográfica HMAC-SHA256
- ✅ **Binding de Hardware** - Licença vinculada ao Machine ID específico
- ✅ **Detecção de Tampering** - Verifica modificações em arquivos críticos
- ✅ **Detecção de Debugger** - Detecta gdb, WinDbg, IDA, x64dbg, etc
- ✅ **Verificação de Integridade** - SHA256 para monitoramento contínuo

---

## 🚀 Instalação

### Requisitos
- Python 3.7+
- Sem dependências externas (usa apenas bibliotecas padrão)

### Setup Rápido

```bash
# 1. Copie os arquivos
cp vm_protection_system.py seu_projeto/
cp exemplo_integracao.py seu_projeto/

# 2. Importe em sua aplicação
from vm_protection_system import VMProtectionSystem
```

---

## 📖 Uso Básico

### 1. Verificação Simples

```python
from vm_protection_system import VMProtectionSystem

protection = VMProtectionSystem()

# Detecta VM
vm_check = protection.detect_virtual_machine()
if vm_check["is_vm"]:
    print(f"⚠️  VM detectada: {vm_check['detection_methods']}")

# Detecta debugger
is_debugged, methods = protection.detect_debugger()
if is_debugged:
    print(f"❌ Debugger: {methods}")
```

### 2. Geração de Licença

```python
# Gerar licença para cliente
license = protection.generate_license(
    customer_name="Empresa XYZ",
    days_valid=365  # Válida por 1 ano
)

# Salvar em arquivo
with open("license.lic", "w") as f:
    f.write(license)
```

### 3. Validação de Licença

```python
# Carregar e validar
with open("license.lic", "r") as f:
    license_data = f.read()

valid, message = protection.validate_license(license_data)
print(message)  # "Licença válida" ou mensagem de erro
```

### 4. Proteção Completa

```python
# Aplicação com todas as verificações
allowed, status = protection.enforce_protection("license.lic")

if allowed:
    print("✅ Aplicação pode executar")
    # Seu código aqui
else:
    print(f"❌ Execução bloqueada:\n{status}")
    sys.exit(1)
```

---

## 🔒 Segurança

### Machine ID

O sistema gera um ID único baseado em hardware:
- UUID do sistema
- Endereço MAC
- Informações de CPU
- Dados específicos de hardware (Windows/Linux)

**Resultado**: Licença vinculada ao computador específico

```python
print(protection.machine_id)
# Exemplo: "a3f5d8b2c1e4f7a9"
```

### Assinatura de Licença

Usa HMAC-SHA256 com chave secreta:

```python
# Servidor gera (chave secreta)
license = protection.generate_license("Cliente")

# Cliente valida (pode verificar mas não falsificar)
valid, msg = protection.validate_license(license)
```

**Segurança contra tampering**: Qualquer modificação invalida a assinatura

---

## 🛡️ Detecções Implementadas

### Detecção de VM (Multiplataforma)

#### Windows
- Verificação WMI (Manufacturer, SystemModel)
- Processos VM (vmtoolsd.exe, vboxservice.exe)
- Registry HARDWARE/DESCRIPTION

#### Linux
- CPU Flags (kvm, xen, hypervisor)
- dmesg logs
- DMI data
- systemd-detect-virt

#### macOS
- System Model (sysctl hw.model)
- ioreg database

### Detecção de Debugger

#### Windows
- windbg.exe
- devenv.exe (Visual Studio)
- ida64.exe (IDA Pro)
- x64dbg.exe
- ollydbg.exe

#### Linux
- gdb
- strace
- ltrace
- valgrind

### Verificação de Integridade

```python
# Registra arquivo para monitoramento
protection.check_integrity("app.exe")  # Primeira execução

# Próximas execuções detectam modificações
is_valid, msg = protection.check_integrity("app.exe")
```

---

## 📦 Estrutura de Licença

A licença é um arquivo JSON assinado:

```json
{
  "data": {
    "customer": "Empresa XYZ",
    "machine_id": "a3f5d8b2c1e4f7a9",
    "issued": "2024-01-15T10:30:00.000000",
    "expires": "2025-01-15T10:30:00.000000",
    "version": "1.0"
  },
  "signature": "a4f7c2e8b1d6f3a9c5e8b2d6f4a1c7e9d2f5a8b1c4e7a0d3f6a9c2e5f8b1"
}
```

---

## 🔐 Implementação em Produção

### Passo 1: Gerar Chave Secreta (Uma vez)

```python
import secrets
secret_key = secrets.token_hex(32)
print(secret_key)
# Guarde em segredo, use em seu servidor
```

### Passo 2: Modificar Chave no Sistema

```python
# Em vm_protection_system.py, altere:
def _sign_license(self, data: str, secret: str = "YOUR-SECRET-KEY-HERE"):
    # Use sua chave secreta!
    ...
```

### Passo 3: Servidor de Geração de Licenças

```python
from exemplo_integracao import LicenseGenerator

generator = LicenseGenerator()

# Quando cliente compra
license_file = generator.generate_for_customer(
    customer_name="Acme Corp",
    days_valid=365
)

# Enviar arquivo de forma segura (HTTPS, email encriptado, etc)
```

### Passo 4: Cliente Integra Licença

```python
# Cliente coloca em: ~/.app_license
# Ou especifica caminho:

app = ProtectedApplication(
    app_name="Minha App",
    license_path="/caminho/para/license.lic"
)

if app.verify_and_start():
    app.run()
```

---

## ⚙️ Configuração Avançada

### Alterar Locais de Arquivo

```python
protection = VMProtectionSystem()
protection.license_file = Path("/etc/meu_app/license.lic")
protection.config_file = Path("/etc/meu_app/config.json")
```

### Server Customizado

```python
protection = VMProtectionSystem(
    license_server="https://seu-servidor.com/licenses"
)
```

### Validação Offline vs Online

**Offline** (implementado):
- Funciona sem internet
- Valida apenas assinatura local
- Recomendado para a maioria dos casos

**Online** (adicionar):
```python
def validate_license_online(self, license_json):
    """Valida contra servidor remoto"""
    response = requests.post(
        f"{self.license_server}/validate",
        json={"license": license_json}
    )
    return response.json()["valid"]
```

---

## 📊 Exemplos de Saída

### Aplicação Protegida - Sucesso

```
============================================================
Iniciando: Minha Aplicação
============================================================

[1/4] Verificando licença...
    ✅ Licença válida

[2/4] Verificando integridade de arquivos...
    ✅ app.exe: Integridade confirmada
    ✅ vm_protection_system.py: Integridade confirmada

[3/4] Verificando debugger...
    ✅ Nenhum debugger detectado

[4/4] Verificando ambiente...
    ✅ Sistema nativo detectado

✅ Todas as verificações passaram!

============================================================
Executando: Minha Aplicação
============================================================

Aplicação rodando normalmente...
Execução concluída com sucesso!
```

### Aplicação Protegida - Falha

```
============================================================
Iniciando: Minha Aplicação
============================================================

[1/4] Verificando licença...
    ❌ Licença expirada

[2/4] Verificando integridade de arquivos...
    ✅ app.exe: Integridade confirmada
    ❌ vm_protection_system.py: ALERTA: Arquivo foi modificado!

[3/4] Verificando debugger...
    ❌ Debugger detectado:
        - Debugger detectado: gdb

[4/4] Verificando ambiente...
    ⚠️  Executando em máquina virtual:
        - CPU Flags (kvm/xen/hypervisor)
    (Funcionalidade limitada em VM)

❌ EXECUÇÃO BLOQUEADA
```

---

## 🔍 Diagnóstico

### Verificar Machine ID

```bash
python -c "from vm_protection_system import VMProtectionSystem; p = VMProtectionSystem(); print(p.machine_id)"
```

### Testar Geração de Licença

```bash
python exemplo_integracao.py --gen-license "Teste Cliente"
```

### Obter Machine ID para Cliente

```bash
python exemplo_integracao.py --show-id
```

---

## 🐛 Solução de Problemas

### Problema: "Licença não é válida para este computador"

**Causa**: Machine ID não coincide (executado em outro PC)

**Solução**: Gerar nova licença no servidor com Machine ID correto do cliente

### Problema: "Arquivo foi modificado"

**Causa**: Arquivo foi editado ou corrompido

**Solução**: 
- Reinstalar aplicação
- Limpar arquivo de configuração: `~/.app_config`

### Problema: "Licença expirada"

**Causa**: Data de expiração ultrapassada

**Solução**: Gerar nova licença com duração maior

### Problema: "Debugger detectado"

**Causa**: Está executando dentro de debugger

**Solução**: Executar fora do debugger ou desativar proteção em versão debug

---

## 📝 Boas Práticas

### ✅ Fazer

- ✅ Usar chave secreta forte (hex aleatório 64 caracteres)
- ✅ Guardar chave secreta em servidor seguro
- ✅ Distribuir licenças via HTTPS
- ✅ Implementar expiração de licença (1 ano recomendado)
- ✅ Fazer backup de máquina ID dos clientes
- ✅ Usar em produção (mude a chave padrão!)

### ❌ Não Fazer

- ❌ Usar chave secreta fraca
- ❌ Compartilhar chave secreta
- ❌ Deixar chave padrão em produção
- ❌ Confiar apenas em detecção de VM (use múltiplas camadas)
- ❌ Armazenar licenças em repositório público

---

## 🔄 Atualizações e Manutenção

### Renovação de Licença

```python
# Antes da expiração, gerar nova
license = protection.generate_license(
    customer_name="Empresa XYZ",
    days_valid=365
)

# Enviar ao cliente
```

### Revogar Licença

```python
# Se necessário, bloquear no servidor:
def is_license_revoked(license_json):
    license_data = json.loads(license_json)
    revoked_list = load_revoked_licenses()
    return license_data["signature"] in revoked_list
```

---

## 📞 Suporte

Para dúvidas:
1. Verifique os exemplos
2. Teste com `exemplo_integracao.py`
3. Leia a documentação do código

---

## 📄 Licença e Uso Legal

Este sistema é para **proteção legítima de direitos autorais**. Use para:
- ✅ Proteger seu software comercial
- ✅ Controlar licenças legitimamente
- ✅ Combater pirataria

Este código é fornecido como exemplo. Adapte conforme necessário para suas necessidades.
