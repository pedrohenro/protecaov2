#!/usr/bin/env python3
"""
Sistema de Proteção contra Pirataria para VMs
Inclui: Detecção de VM, Validação de Licença, Anti-Tampering
"""

import os
import sys
import json
import hashlib
import hmac
import uuid
import platform
import subprocess
import socket
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Tuple, Optional
import subprocess
import re

class VMProtectionSystem:
    def __init__(self, license_server: str = "https://seu-servidor-licenca.com"):
        self.license_server = license_server
        self.license_file = Path.home() / ".app_license"
        self.config_file = Path.home() / ".app_config"
        self.machine_id = self._get_machine_id()
        
    # ============ DETECÇÃO DE VM ============
    
    def detect_virtual_machine(self) -> Dict[str, any]:
        """Detecta se o sistema está rodando em máquina virtual"""
        detections = {
            "is_vm": False,
            "vm_type": None,
            "detection_methods": []
        }
        
        # Windows
        if platform.system() == "Windows":
            detections.update(self._detect_vm_windows())
        # Linux
        elif platform.system() == "Linux":
            detections.update(self._detect_vm_linux())
        # macOS
        elif platform.system() == "Darwin":
            detections.update(self._detect_vm_macos())
        
        return detections
    
    def _detect_vm_windows(self) -> Dict:
        """Detecta VM em Windows"""
        vm_indicators = []
        
        try:
            # Verifica via WMI
            result = subprocess.run(
                ['wmic', 'os', 'get', 'manufacturer'],
                capture_output=True,
                text=True,
                timeout=5
            )
            if "VMware" in result.stdout or "VirtualBox" in result.stdout or "Hyper-V" in result.stdout:
                vm_indicators.append("WMI Manufacturer")
        except:
            pass
        
        try:
            # Verifica processos VM
            result = subprocess.run(
                ['tasklist'],
                capture_output=True,
                text=True,
                timeout=5
            )
            vm_processes = ['vmtoolsd.exe', 'vmware.exe', 'vboxservice.exe', 'vboxsvc.exe']
            for proc in vm_processes:
                if proc in result.stdout:
                    vm_indicators.append(f"Process: {proc}")
        except:
            pass
        
        try:
            # Verifica registry
            result = subprocess.run(
                ['reg', 'query', 'HKLM\\HARDWARE\\DESCRIPTION\\System'],
                capture_output=True,
                text=True,
                timeout=5
            )
            if "VirtualBox" in result.stdout or "VMware" in result.stdout:
                vm_indicators.append("Registry")
        except:
            pass
        
        is_vm = len(vm_indicators) > 0
        return {
            "is_vm": is_vm,
            "vm_type": "Potentially Virtualized",
            "detection_methods": vm_indicators
        }
    
    def _detect_vm_linux(self) -> Dict:
        """Detecta VM em Linux"""
        vm_indicators = []
        
        # Verifica /proc/cpuinfo
        try:
            with open('/proc/cpuinfo', 'r') as f:
                content = f.read()
                if 'kvm' in content or 'xen' in content or 'hypervisor' in content:
                    vm_indicators.append("CPU Flags (kvm/xen/hypervisor)")
        except:
            pass
        
        # Verifica dmesg
        try:
            result = subprocess.run(['dmesg'], capture_output=True, text=True, timeout=5)
            if 'VirtualBox' in result.stdout or 'VMware' in result.stdout or 'Hyper-V' in result.stdout:
                vm_indicators.append("dmesg")
        except:
            pass
        
        # Verifica DMI
        try:
            result = subprocess.run(
                ['dmidecode', '-s', 'system-product-name'],
                capture_output=True,
                text=True,
                timeout=5
            )
            if 'VirtualBox' in result.stdout or 'VMware' in result.stdout:
                vm_indicators.append("DMI")
        except:
            pass
        
        # Verifica se systemd-detect-virt existe
        try:
            result = subprocess.run(
                ['systemd-detect-virt'],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.stdout.strip() != 'none':
                vm_indicators.append(f"systemd-detect-virt: {result.stdout.strip()}")
        except:
            pass
        
        is_vm = len(vm_indicators) > 0
        return {
            "is_vm": is_vm,
            "vm_type": "Potentially Virtualized",
            "detection_methods": vm_indicators
        }
    
    def _detect_vm_macos(self) -> Dict:
        """Detecta VM em macOS"""
        vm_indicators = []
        
        try:
            result = subprocess.run(
                ['sysctl', 'hw.model'],
                capture_output=True,
                text=True,
                timeout=5
            )
            if 'VMware' in result.stdout or 'VirtualBox' in result.stdout:
                vm_indicators.append("System Model")
        except:
            pass
        
        try:
            result = subprocess.run(
                ['ioreg', '-l'],
                capture_output=True,
                text=True,
                timeout=5
            )
            if 'VMware' in result.stdout or 'VirtualBox' in result.stdout:
                vm_indicators.append("ioreg")
        except:
            pass
        
        is_vm = len(vm_indicators) > 0
        return {
            "is_vm": is_vm,
            "vm_type": "Potentially Virtualized",
            "detection_methods": vm_indicators
        }
    
    # ============ GERENCIAMENTO DE MÁQUINA ID ============
    
    def _get_machine_id(self) -> str:
        """Gera ID único da máquina baseado em hardware"""
        hardware_data = []
        
        # Coleta dados de hardware
        hardware_data.append(platform.machine())
        hardware_data.append(platform.processor())
        
        try:
            mac = uuid.getnode()
            hardware_data.append(str(mac))
        except:
            pass
        
        # Tenta usar hardware serial em Windows
        if platform.system() == "Windows":
            try:
                result = subprocess.run(
                    ['wmic', 'csproduct', 'get', 'UUID'],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                hardware_data.append(result.stdout.strip())
            except:
                pass
        
        # Cria hash do hardware
        combined = "|".join(hardware_data)
        machine_id = hashlib.sha256(combined.encode()).hexdigest()[:16]
        return machine_id
    
    # ============ GERAÇÃO E VALIDAÇÃO DE LICENÇA ============
    
    def generate_license(self, customer_name: str, days_valid: int = 365) -> str:
        """Gera uma licença assinada"""
        license_data = {
            "customer": customer_name,
            "machine_id": self.machine_id,
            "issued": datetime.now().isoformat(),
            "expires": (datetime.now() + timedelta(days=days_valid)).isoformat(),
            "version": "1.0"
        }
        
        # Serializa e assina
        license_json = json.dumps(license_data, sort_keys=True)
        signature = self._sign_license(license_json)
        
        license_package = {
            "data": license_data,
            "signature": signature
        }
        
        return json.dumps(license_package)
    
    def _sign_license(self, data: str, secret: str = "your-secret-key") -> str:
        """Assina licença com HMAC-SHA256"""
        signature = hmac.new(
            secret.encode(),
            data.encode(),
            hashlib.sha256
        ).hexdigest()
        return signature
    
    def validate_license(self, license_json: str) -> Tuple[bool, str]:
        """Valida licença assinada"""
        try:
            license_package = json.loads(license_json)
            data = license_package["data"]
            signature = license_package["signature"]
            
            # Verifica assinatura
            data_json = json.dumps(data, sort_keys=True)
            expected_signature = self._sign_license(data_json)
            
            if not hmac.compare_digest(signature, expected_signature):
                return False, "Assinatura inválida - licença modificada"
            
            # Verifica machine_id
            if data.get("machine_id") != self.machine_id:
                return False, "Licença não é válida para este computador"
            
            # Verifica expiração
            expires = datetime.fromisoformat(data["expires"])
            if datetime.now() > expires:
                return False, "Licença expirada"
            
            return True, "Licença válida"
        
        except json.JSONDecodeError:
            return False, "Formato de licença inválido"
        except Exception as e:
            return False, f"Erro ao validar licença: {str(e)}"
    
    # ============ DETECÇÃO DE TAMPERING ============
    
    def check_integrity(self, file_path: str) -> Tuple[bool, str]:
        """Verifica integridade de arquivo"""
        try:
            if not os.path.exists(file_path):
                return False, "Arquivo não encontrado"
            
            # Calcula hash atual
            current_hash = self._calculate_file_hash(file_path)
            
            # Carrega hash armazenado
            config = self._load_config()
            stored_hashes = config.get("file_hashes", {})
            
            if file_path not in stored_hashes:
                # Armazena hash na primeira verificação
                stored_hashes[file_path] = current_hash
                config["file_hashes"] = stored_hashes
                self._save_config(config)
                return True, "Arquivo registrado para monitoramento"
            
            if current_hash == stored_hashes[file_path]:
                return True, "Integridade confirmada"
            else:
                return False, "ALERTA: Arquivo foi modificado!"
        
        except Exception as e:
            return False, f"Erro ao verificar integridade: {str(e)}"
    
    def _calculate_file_hash(self, file_path: str) -> str:
        """Calcula SHA256 de arquivo"""
        sha256 = hashlib.sha256()
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b''):
                sha256.update(chunk)
        return sha256.hexdigest()
    
    # ============ DETECÇÃO DE DEBUGGING ============
    
    def detect_debugger(self) -> Tuple[bool, list]:
        """Detecta se aplicação está sendo debugada"""
        detected_methods = []
        
        if platform.system() == "Windows":
            detected_methods.extend(self._detect_debugger_windows())
        elif platform.system() == "Linux":
            detected_methods.extend(self._detect_debugger_linux())
        
        return len(detected_methods) > 0, detected_methods
    
    def _detect_debugger_windows(self) -> list:
        """Detecta debugger em Windows"""
        methods = []
        
        try:
            result = subprocess.run(
                ['tasklist'],
                capture_output=True,
                text=True,
                timeout=5
            )
            debuggers = ['windbg.exe', 'devenv.exe', 'ida64.exe', 'x64dbg.exe', 'ollydbg.exe']
            for dbg in debuggers:
                if dbg in result.stdout:
                    methods.append(f"Debugger detectado: {dbg}")
        except:
            pass
        
        return methods
    
    def _detect_debugger_linux(self) -> list:
        """Detecta debugger em Linux"""
        methods = []
        
        try:
            # Verifica se está sendo rastreado por strace/gdb
            result = subprocess.run(
                ['ps', 'aux'],
                capture_output=True,
                text=True,
                timeout=5
            )
            debuggers = ['gdb', 'strace', 'ltrace', 'valgrind']
            for dbg in debuggers:
                if dbg in result.stdout:
                    methods.append(f"Debugger detectado: {dbg}")
        except:
            pass
        
        return methods
    
    # ============ PERSISTÊNCIA DE CONFIGURAÇÃO ============
    
    def _load_config(self) -> Dict:
        """Carrega configuração salva"""
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    return json.load(f)
            except:
                return {}
        return {}
    
    def _save_config(self, config: Dict):
        """Salva configuração"""
        try:
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2)
            os.chmod(self.config_file, 0o600)
        except Exception as e:
            print(f"Erro ao salvar config: {e}")
    
    # ============ PROTEÇÃO EM TEMPO DE EXECUÇÃO ============
    
    def enforce_protection(self, license_path: str) -> Tuple[bool, str]:
        """Aplica todas as proteções e retorna se aplicação pode rodar"""
        protections = []
        failed = []
        
        # 1. Verifica detecção de VM (aviso, não bloqueia)
        vm_check = self.detect_virtual_machine()
        if vm_check["is_vm"]:
            protections.append(f"⚠️  VM Detectada: {vm_check['detection_methods']}")
        
        # 2. Valida licença
        if not os.path.exists(license_path):
            failed.append("❌ Licença não encontrada")
        else:
            try:
                with open(license_path, 'r') as f:
                    license_data = f.read()
                valid, msg = self.validate_license(license_data)
                if valid:
                    protections.append(f"✅ {msg}")
                else:
                    failed.append(f"❌ {msg}")
            except Exception as e:
                failed.append(f"❌ Erro ao ler licença: {e}")
        
        # 3. Detecta debugger
        is_debugged, methods = self.detect_debugger()
        if is_debugged:
            failed.append(f"❌ Debugger detectado: {methods}")
        
        # Resultado final
        all_passed = len(failed) == 0
        status = "\n".join(protections + failed)
        
        return all_passed, status


# ============ EXEMPLO DE USO ============

def main():
    protection = VMProtectionSystem()
    
    print("=" * 60)
    print("Sistema de Proteção contra Pirataria v1.0")
    print("=" * 60)
    
    # 1. Detecta VM
    print("\n[1] Verificando Máquina Virtual...")
    vm_check = protection.detect_virtual_machine()
    if vm_check["is_vm"]:
        print(f"⚠️  VM DETECTADA!")
        for method in vm_check["detection_methods"]:
            print(f"   - {method}")
    else:
        print("✅ Sistema nativo detectado")
    
    # 2. Exibe Machine ID
    print(f"\n[2] Machine ID: {protection.machine_id}")
    
    # 3. Gera licença de exemplo
    print("\n[3] Gerando licença de exemplo...")
    license = protection.generate_license("Empresa XYZ", days_valid=30)
    print("Licença gerada (salvar em arquivo):")
    print(license[:100] + "...")
    
    # 4. Valida licença
    print("\n[4] Validando licença...")
    valid, msg = protection.validate_license(license)
    print(f"Resultado: {msg}")
    
    # 5. Detecta debugger
    print("\n[5] Verificando debugger...")
    is_debugged, methods = protection.detect_debugger()
    if is_debugged:
        print(f"⚠️  Debugger detectado: {methods}")
    else:
        print("✅ Nenhum debugger detectado")
    
    # 6. Enforcement
    print("\n[6] Aplicando proteção completa...")
    license_file = "test.license"
    
    # Salva licença de teste
    with open(license_file, 'w') as f:
        f.write(license)
    
    allowed, status = protection.enforce_protection(license_file)
    print(status)
    print(f"\n{'✅ APLICAÇÃO PODE EXECUTAR' if allowed else '❌ EXECUÇÃO BLOQUEADA'}")


if __name__ == "__main__":
    main()
