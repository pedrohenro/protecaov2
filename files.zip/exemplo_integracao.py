#!/usr/bin/env python3
"""
Exemplo de Integração: Aplicação Protegida contra Pirataria
Mostra como integrar o sistema de proteção em sua aplicação
"""

import sys
from pathlib import Path
from vm_protection_system import VMProtectionSystem

class ProtectedApplication:
    """Aplicação que usa sistema de proteção"""
    
    def __init__(self, app_name: str, license_path: str):
        self.app_name = app_name
        self.license_path = license_path
        self.protection = VMProtectionSystem()
        self.is_protected = False
    
    def verify_and_start(self) -> bool:
        """Verifica proteção antes de iniciar aplicação"""
        print(f"\n{'='*60}")
        print(f"Iniciando: {self.app_name}")
        print(f"{'='*60}\n")
        
        # Etapa 1: Verificar licença
        if not self._verify_license():
            print("❌ Falha na verificação de licença. Encerrando.")
            return False
        
        # Etapa 2: Verificar integridade de arquivos críticos
        if not self._verify_integrity():
            print("❌ Falha na verificação de integridade. Encerrando.")
            return False
        
        # Etapa 3: Verificar debugger
        if not self._check_debugger():
            print("❌ Debugger detectado. Encerrando.")
            return False
        
        # Etapa 4: Avisar sobre VM (não bloqueia)
        self._check_vm()
        
        print("\n✅ Todas as verificações passaram!")
        self.is_protected = True
        return True
    
    def _verify_license(self) -> bool:
        """Verifica se licença é válida"""
        print("[1/4] Verificando licença...")
        
        license_path = Path(self.license_path)
        if not license_path.exists():
            print(f"    ❌ Licença não encontrada em: {self.license_path}")
            return False
        
        try:
            with open(license_path, 'r') as f:
                license_data = f.read()
            
            valid, message = self.protection.validate_license(license_data)
            
            if valid:
                print(f"    ✅ {message}")
                return True
            else:
                print(f"    ❌ {message}")
                return False
        
        except Exception as e:
            print(f"    ❌ Erro ao ler licença: {e}")
            return False
    
    def _verify_integrity(self) -> bool:
        """Verifica integridade de arquivos críticos"""
        print("[2/4] Verificando integridade de arquivos...")
        
        # Lista arquivos críticos para verificar
        critical_files = [
            __file__,  # Este script
            "vm_protection_system.py"  # O módulo de proteção
        ]
        
        all_ok = True
        for file_path in critical_files:
            if Path(file_path).exists():
                valid, msg = self.protection.check_integrity(file_path)
                status = "✅" if valid else "❌"
                print(f"    {status} {file_path}: {msg}")
                if not valid:
                    all_ok = False
        
        return all_ok
    
    def _check_debugger(self) -> bool:
        """Detecta se está sendo debugado"""
        print("[3/4] Verificando debugger...")
        
        is_debugged, methods = self.protection.detect_debugger()
        
        if is_debugged:
            print(f"    ❌ Debugger detectado:")
            for method in methods:
                print(f"        - {method}")
            return False
        else:
            print("    ✅ Nenhum debugger detectado")
            return True
    
    def _check_vm(self):
        """Verifica VM (apenas aviso)"""
        print("[4/4] Verificando ambiente...")
        
        vm_check = self.protection.detect_virtual_machine()
        
        if vm_check["is_vm"]:
            print(f"    ⚠️  Executando em máquina virtual:")
            for method in vm_check["detection_methods"]:
                print(f"        - {method}")
            print("    (Funcionalidade limitada em VM)")
        else:
            print("    ✅ Sistema nativo detectado")
    
    def run(self):
        """Executa aplicação protegida"""
        if not self.is_protected:
            print("❌ Aplicação não foi verificada. Execute verify_and_start() primeiro.")
            return
        
        print(f"\n{'='*60}")
        print(f"Executando: {self.app_name}")
        print(f"{'='*60}\n")
        
        # Seu código de aplicação aqui
        print("Aplicação rodando normalmente...")
        print("(Insira seu código aqui)")
        print("\nExecução concluída com sucesso!")


# ============ GERADOR DE LICENÇA ============

class LicenseGenerator:
    """Ferramenta para gerar licenças (execute em servidor seguro)"""
    
    def __init__(self):
        self.protection = VMProtectionSystem()
    
    def generate_for_customer(self, customer_name: str, days_valid: int = 365):
        """Gera licença para cliente"""
        print(f"\nGerando licença para: {customer_name}")
        print(f"Válida por: {days_valid} dias")
        
        license = self.protection.generate_license(customer_name, days_valid)
        
        # Salva em arquivo
        filename = f"license_{customer_name.replace(' ', '_').lower()}.lic"
        
        with open(filename, 'w') as f:
            f.write(license)
        
        print(f"✅ Licença salva em: {filename}")
        print(f"\nEnviar este arquivo ao cliente:")
        print(f"   - Distribuir de forma segura")
        print(f"   - Colocar em: {Path.home() / '.app_license'}")
        print(f"   - Ou especificar caminho ao iniciar aplicação")
        
        return filename
    
    def list_machine_ids(self):
        """Lista IDs de máquinas para referência"""
        print(f"\nMachine ID da máquina de desenvolvimento:")
        print(f"   {self.protection.machine_id}")
        print(f"\nOs clientes podem obter seu Machine ID rodando:")
        print(f"   python license_generator.py --show-id")


# ============ EXEMPLOS DE USO ============

def example_1_basic_usage():
    """Exemplo 1: Uso básico"""
    print("\n" + "="*60)
    print("EXEMPLO 1: Uso Básico")
    print("="*60)
    
    # Gera licença
    generator = LicenseGenerator()
    license_file = generator.generate_for_customer("Cliente Teste", days_valid=30)
    
    # Aplicação protegida
    app = ProtectedApplication(
        app_name="Minha Aplicação",
        license_path=license_file
    )
    
    if app.verify_and_start():
        app.run()


def example_2_manual_verification():
    """Exemplo 2: Verificação manual de componentes"""
    print("\n" + "="*60)
    print("EXEMPLO 2: Verificação Manual")
    print("="*60)
    
    protection = VMProtectionSystem()
    
    # Verifica VM
    print("\n[VM Detection]")
    vm = protection.detect_virtual_machine()
    print(f"Is VM: {vm['is_vm']}")
    if vm['is_vm']:
        print(f"Methods: {vm['detection_methods']}")
    
    # Verifica Debugger
    print("\n[Debugger Detection]")
    is_debugged, methods = protection.detect_debugger()
    print(f"Is Debugged: {is_debugged}")
    if is_debugged:
        print(f"Methods: {methods}")
    
    # Machine ID
    print(f"\n[Machine ID]")
    print(f"ID: {protection.machine_id}")


def example_3_license_validation():
    """Exemplo 3: Validação de licença"""
    print("\n" + "="*60)
    print("EXEMPLO 3: Validação de Licença")
    print("="*60)
    
    protection = VMProtectionSystem()
    
    # Gera licença
    license = protection.generate_license("Empresa ABC", days_valid=365)
    print(f"\nLicença gerada:")
    print(license[:150] + "...")
    
    # Valida licença
    valid, msg = protection.validate_license(license)
    print(f"\nValidação: {msg}")
    
    # Tenta modificar licença
    print("\nTentando modificar licença...")
    modified = license.replace("ABC", "XYZ")
    valid, msg = protection.validate_license(modified)
    print(f"Validação: {msg}")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "--gen-license":
            if len(sys.argv) > 2:
                generator = LicenseGenerator()
                generator.generate_for_customer(sys.argv[2])
            else:
                print("Uso: python exemplo_integracao.py --gen-license 'Nome Cliente'")
        
        elif sys.argv[1] == "--show-id":
            generator = LicenseGenerator()
            generator.list_machine_ids()
    
    else:
        # Executa exemplos
        example_1_basic_usage()
        # example_2_manual_verification()
        # example_3_license_validation()
